/**
  ******************************************************************************
  * @file    system_stm32g4xx.c
  * @author  MCD Application Team
  * @brief   CMSIS Cortex-M4 Device Peripheral Access Layer System Source File
  *
  *   This file provides two functions and one global variable to be called from
  *   user application:
  *      - SystemInit(): This function is called at startup just after reset and
  *                      before branch to main program. This call is made inside
  *                      the "startup_stm32g4xx.s" file.
  *
  *      - SystemCoreClock variable: Contains the core clock (HCLK), it can be used
  *                                  by the user application to setup the SysTick
  *                                  timer or configure other parameters.
  *
  *      - SystemCoreClockUpdate(): Updates the variable SystemCoreClock and must
  *                                 be called whenever the core clock is changed
  *                                 during program execution.
  *
  *   After each device reset the HSI (16 MHz) is used as system clock source.
  *   Then SystemInit() function is called, in "startup_stm32g4xx.s" file, to
  *   configure the system clock before to branch to main program.
  *
  *   This file configures the system clock as follows:
  *=============================================================================
  *-----------------------------------------------------------------------------
  *        System Clock source                    | HSI
  *-----------------------------------------------------------------------------
  *        SYSCLK(Hz)                             | 16000000
  *-----------------------------------------------------------------------------
  *        HCLK(Hz)                               | 16000000
  *-----------------------------------------------------------------------------
  *        AHB Prescaler                          | 1
  *-----------------------------------------------------------------------------
  *        APB1 Prescaler                         | 1
  *-----------------------------------------------------------------------------
  *        APB2 Prescaler                         | 1
  *-----------------------------------------------------------------------------
  *        PLL_M                                  | 1
  *-----------------------------------------------------------------------------
  *        PLL_N                                  | 16
  *-----------------------------------------------------------------------------
  *        PLL_P                                  | 7
  *-----------------------------------------------------------------------------
  *        PLL_Q                                  | 2
  *-----------------------------------------------------------------------------
  *        PLL_R                                  | 2
  *-----------------------------------------------------------------------------
  *        Require 48MHz for RNG                  | Disabled
  *-----------------------------------------------------------------------------
  *=============================================================================
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/** @addtogroup CMSIS
  * @{
  */

/** @addtogroup stm32g4xx_system
  * @{
  */

/** @addtogroup STM32G4xx_System_Private_Includes
  * @{
  */

#include "stm32g4xx.h"                                                                                   // Includes declarations from stm32g4xx.h required by this source file.

#if !defined  (HSE_VALUE)                                                                                // Compiles the following block only when this preprocessor condition is true.
  #define HSE_VALUE     24000000U /*!< Value of the External oscillator in Hz */
#endif /* HSE_VALUE */

#if !defined  (HSI_VALUE)                                                                                // Compiles the following block only when this preprocessor condition is true.
  #define HSI_VALUE    16000000U /*!< Value of the Internal oscillator in Hz*/
#endif /* HSI_VALUE */

/**
  * @}
  */

/** @addtogroup STM32G4xx_System_Private_TypesDefinitions
  * @{
  */

/**
  * @}
  */

/** @addtogroup STM32G4xx_System_Private_Defines
  * @{
  */

/************************* Miscellaneous Configuration ************************/
/* Note: Following vector table addresses must be defined in line with linker
         configuration. */
/*!< Uncomment the following line if you need to relocate the vector table
     anywhere in Flash or Sram, else the vector table is kept at the automatic
     remap of boot address selected */
/* #define USER_VECT_TAB_ADDRESS */

#if defined(USER_VECT_TAB_ADDRESS)                                                                       // Compiles the following block only when this preprocessor condition is true.
/*!< Uncomment the following line if you need to relocate your vector Table
     in Sram else user remap will be done in Flash. */
/* #define VECT_TAB_SRAM */
#if defined(VECT_TAB_SRAM)                                                                               // Compiles the following block only when this preprocessor condition is true.
#define VECT_TAB_BASE_ADDRESS   SRAM_BASE       /*!< Vector Table base address field.
                                                     This value must be a multiple of 0x200. */
#else                                                                                                    // Selects the alternative branch of the current compile-time condition.
#define VECT_TAB_BASE_ADDRESS   FLASH_BASE      /*!< Vector Table base address field.
                                                     This value must be a multiple of 0x200. */
#endif /* VECT_TAB_SRAM */

#if !defined(VECT_TAB_OFFSET)                                                                            // Compiles the following block only when this preprocessor condition is true.
#define VECT_TAB_OFFSET         0x00000000U     /*!< Vector Table offset field.
                                                     This value must be a multiple of 0x200. */
#endif /* VECT_TAB_OFFSET */

#endif /* USER_VECT_TAB_ADDRESS */
/******************************************************************************/
/**
  * @}
  */

/** @addtogroup STM32G4xx_System_Private_Macros
  * @{
  */

/**
  * @}
  */

/** @addtogroup STM32G4xx_System_Private_Variables
  * @{
  */
  /* The SystemCoreClock variable is updated in three ways:
      1) by calling CMSIS function SystemCoreClockUpdate()
      2) by calling HAL API function HAL_RCC_GetHCLKFreq()
      3) each time HAL_RCC_ClockConfig() is called to configure the system clock frequency
         Note: If you use this function to configure the system clock; then there
               is no need to call the 2 first functions listed above, since SystemCoreClock
               variable is updated automatically.
  */
  uint32_t SystemCoreClock = HSI_VALUE;                                                                  // Declares SystemCoreClock and initializes it with HSI_VALUE.

  const uint8_t AHBPrescTable[16] = {0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 1U, 2U, 3U, 4U, 6U, 7U, 8U, 9U};    // Sets const uint8_t AHBPrescTable[16] to {0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 1U, 2U, 3U, 4U, 6U, 7U, 8U, 9U}.
  const uint8_t APBPrescTable[8] =  {0U, 0U, 0U, 0U, 1U, 2U, 3U, 4U};                                    // Sets const uint8_t APBPrescTable[8] to {0U, 0U, 0U, 0U, 1U, 2U, 3U, 4U}.

/**
  * @}
  */

/** @addtogroup STM32G4xx_System_Private_FunctionPrototypes
  * @{
  */

/**
  * @}
  */

/** @addtogroup STM32G4xx_System_Private_Functions
  * @{
  */

/**
  * @brief  Setup the microcontroller system.
  * @param  None
  * @retval None
  */

void SystemInit(void)                                                                                    // Defines the CMSIS system initialization routine executed after reset.
{                                                                                                        // Opens the current code block.
  /* FPU settings ------------------------------------------------------------*/
  #if (__FPU_PRESENT == 1) && (__FPU_USED == 1)                                                          // Compiles the following block only when this preprocessor condition is true.
    SCB->CPACR |= ((3UL << (10*2))|(3UL << (11*2)));  /* set CP10 and CP11 Full Access */
  #endif                                                                                                 // Ends the current conditional-compilation block.

  /* Configure the Vector Table location add offset address ------------------*/
#if defined(USER_VECT_TAB_ADDRESS)                                                                       // Compiles the following block only when this preprocessor condition is true.
  SCB->VTOR = VECT_TAB_BASE_ADDRESS | VECT_TAB_OFFSET; /* Vector Table Relocation in Internal SRAM */
#endif /* USER_VECT_TAB_ADDRESS */
}                                                                                                        // Closes the current code block.

/**
  * @brief  Update SystemCoreClock variable according to Clock Register Values.
  *         The SystemCoreClock variable contains the core clock (HCLK), it can
  *         be used by the user application to setup the SysTick timer or configure
  *         other parameters.
  *
  * @note   Each time the core clock (HCLK) changes, this function must be called
  *         to update SystemCoreClock variable value. Otherwise, any configuration
  *         based on this variable will be incorrect.
  *
  * @note   - The system frequency computed by this function is not the real
  *           frequency in the chip. It is calculated based on the predefined
  *           constant and the selected clock source:
  *
  *           - If SYSCLK source is HSI, SystemCoreClock will contain the HSI_VALUE(**)
  *
  *           - If SYSCLK source is HSE, SystemCoreClock will contain the HSE_VALUE(***)
  *
  *           - If SYSCLK source is PLL, SystemCoreClock will contain the HSE_VALUE(***)
  *             or HSI_VALUE(*) multiplied/divided by the PLL factors.
  *
  *         (**) HSI_VALUE is a constant defined in stm32g4xx_hal.h file (default value
  *              16 MHz) but the real value may vary depending on the variations
  *              in voltage and temperature.
  *
  *         (***) HSE_VALUE is a constant defined in stm32g4xx_hal.h file (default value
  *              24 MHz), user has to ensure that HSE_VALUE is same as the real
  *              frequency of the crystal used. Otherwise, this function may
  *              have wrong result.
  *
  *         - The result of this function could be not correct when using fractional
  *           value for HSE crystal.
  *
  * @param  None
  * @retval None
  */
void SystemCoreClockUpdate(void)                                                                         // Defines the routine that recalculates the SystemCoreClock variable.
{                                                                                                        // Opens the current code block.
  uint32_t tmp, pllvco, pllr, pllsource, pllm;                                                           // Executes this statement as part of the current control flow.

  /* Get SYSCLK source -------------------------------------------------------*/
  switch (RCC->CFGR & RCC_CFGR_SWS)                                                                      // Selects behavior according to the value of RCC->CFGR & RCC_CFGR_SWS.
  {                                                                                                      // Opens the current code block.
    case 0x04:  /* HSI used as system clock source */
      SystemCoreClock = HSI_VALUE;                                                                       // Sets SystemCoreClock to HSI_VALUE.
      break;                                                                                             // Exits the current switch branch or loop.

    case 0x08:  /* HSE used as system clock source */
      SystemCoreClock = HSE_VALUE;                                                                       // Sets SystemCoreClock to HSE_VALUE.
      break;                                                                                             // Exits the current switch branch or loop.

    case 0x0C:  /* PLL used as system clock  source */
      /* PLL_VCO = (HSE_VALUE or HSI_VALUE / PLLM) * PLLN
         SYSCLK = PLL_VCO / PLLR
         */
      pllsource = (RCC->PLLCFGR & RCC_PLLCFGR_PLLSRC);                                                   // Sets pllsource to (RCC->PLLCFGR & RCC_PLLCFGR_PLLSRC).
      pllm = ((RCC->PLLCFGR & RCC_PLLCFGR_PLLM) >> 4) + 1U ;                                             // Sets pllm to ((RCC->PLLCFGR & RCC_PLLCFGR_PLLM) >> 4) + 1U.
      if (pllsource == 0x02UL) /* HSI used as PLL clock source */
      {                                                                                                  // Opens the current code block.
        pllvco = (HSI_VALUE / pllm);                                                                     // Sets pllvco to (HSI_VALUE / pllm).
      }                                                                                                  // Closes the current code block.
      else                   /* HSE used as PLL clock source */
      {                                                                                                  // Opens the current code block.
        pllvco = (HSE_VALUE / pllm);                                                                     // Sets pllvco to (HSE_VALUE / pllm).
      }                                                                                                  // Closes the current code block.
      pllvco = pllvco * ((RCC->PLLCFGR & RCC_PLLCFGR_PLLN) >> 8);                                        // Sets pllvco to pllvco * ((RCC->PLLCFGR & RCC_PLLCFGR_PLLN) >> 8).
      pllr = (((RCC->PLLCFGR & RCC_PLLCFGR_PLLR) >> 25) + 1U) * 2U;                                      // Sets pllr to (((RCC->PLLCFGR & RCC_PLLCFGR_PLLR) >> 25) + 1U) * 2U.
      SystemCoreClock = pllvco/pllr;                                                                     // Sets SystemCoreClock to pllvco/pllr.
      break;                                                                                             // Exits the current switch branch or loop.

    default:                                                                                             // Handles all switch values not matched by a previous case.
      break;                                                                                             // Exits the current switch branch or loop.
  }                                                                                                      // Closes the current code block.
  /* Compute HCLK clock frequency --------------------------------------------*/
  /* Get HCLK prescaler */
  tmp = AHBPrescTable[((RCC->CFGR & RCC_CFGR_HPRE) >> 4)];                                               // Sets tmp to AHBPrescTable[((RCC->CFGR & RCC_CFGR_HPRE) >> 4)].
  /* HCLK clock frequency */
  SystemCoreClock >>= tmp;                                                                               // Executes this statement as part of the current control flow.
}                                                                                                        // Closes the current code block.


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */


